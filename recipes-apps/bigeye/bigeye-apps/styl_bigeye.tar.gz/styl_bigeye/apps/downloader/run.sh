#!/bin/bash
#/******************************************************************************
# *  (C) Copyright 2008 STYL Solutions Pte. Ltd. , All rights reserved          *
# *                                                                             *
# *  This source code and any compilation or derivative thereof is the sole     *
# *  property of STYL Solutions Pte. Ltd. and is provided pursuant to a         *
# *  Software License Agreement.  This code is the proprietary information of   *
# *  STYL Solutions Pte. Ltd. and is confidential in nature. Its use and        *
# *  dissemination by any party other than STYL Solutions Pte. Ltd. is strictly *
# *  limited by the confidential information provisions of the Agreement        *
# *  referenced above.                                                          *
# ******************************************************************************/

# define
PATH_TO_FOLDER_ROOT=/home/root/styl_bigeye
PATH_TO_FOLDER_APP=$PATH_TO_FOLDER_ROOT/apps
PATH_TO_FOLDER_DOWNLOADER_APP=$PATH_TO_FOLDER_APP/downloader
PATH_TO_FOLDER_DOWNLOAD=$PATH_TO_FOLDER_ROOT/download
PATH_TO_FOLDER_FLASHINGAPP=$PATH_TO_FOLDER_APP/flashingapp
DOWNLOAD_FILE_NAME=app.tar.gz


# change
PATH_CONFIG_FILE=$PATH_TO_FOLDER_APP/bigeye/config.xml
PATH_TO_SIGNATURE_FILE=$PATH_TO_FOLDER_FLASHINGAPP/content.tar.gz.sig
SLEEP_TIME_S=60

# code
EXIT_CODE_NORMAL=0
EXIT_CODE_DOWNLOADED=1

# variable
ApiKey=""
URL=""
API_URL=""
TerminalID=""

## get API key
function configGetAPIKey {
	ApiKey=$(cat $PATH_CONFIG_FILE | awk 'gsub(/<apiKey>|<\/apiKey>/,x)')
	echo "ApiKey:" "${ApiKey}"
}

## get URL
function configGetURL {
    URL=$(cat $PATH_CONFIG_FILE | awk 'gsub(/<url>|<\/url>/,x)')
	echo "URL:" "${URL}"

	API_URL=$URL/terminal/ota/check
}

## get terminal ID
function configGetTerminalID {
	TerminalID=$(cat $PATH_CONFIG_FILE | awk 'gsub(/<terminalId>|<\/terminalId>/,x)')
	echo "TerminalID:" "${TerminalID}"
}

## run app downloader
function run_downloader {
	cd ${PATH_TO_FOLDER_DOWNLOADER_APP}
	./downloader -u ${API_URL} -t ${TerminalID} -a ${ApiKey} -p ${PATH_TO_FOLDER_DOWNLOAD} -n ${DOWNLOAD_FILE_NAME} -s ${PATH_TO_SIGNATURE_FILE} -d true

}

## main process
function do_process {
	while [ 1 ]
	do
		# get terminal id
		configGetTerminalID

		# get API key
		configGetAPIKey

		# get url
		configGetURL
	
		# check if terminal id empty so wait until it's not empty to run the app
		if [ "$TerminalID" == "" ]; then
			# no terminal id, wait to check again
			echo "TerminalID empty!"
		else
			echo "Run app downloader"
			# run app downloader
			run_downloader

			# check exit code
			EXIT_CODE=$?
			echo "Exit code: ${EXIT_CODE}"
			if [ $EXIT_CODE == $EXIT_CODE_DOWNLOADED ]; then
				echo "Reboot to update"
				sync
				reboot
				exit 1
			else
				echo "No file to download"
			fi
		fi

		# sleep to wait for next round
		echo "Sleep ${SLEEP_TIME_S}"
		sleep $SLEEP_TIME_S
	done

}

# run main process
do_process
