#!/bin/bash
#/******************************************************************************
# *  (C) Copyright 2008 STYL Solutions Pte. Ltd. , All rights reserved          *
# *                                                                             *
# *  This source code and any compilation or derivative thereof is the sole     *
# *  property of STYL Solutions Pte. Ltd. and is provided pursuant to a         *
# *  Software License Agreement.  This code is the proprietary information of   *
# *  STYL Solutions Pte. Ltd. and is confidential in nature. Its use and        *
# *  dissemination by any party other than STYL Solutions Pte. Ltd. is strictly *
# *  limited by the confidential information provisions of the Agreement        *
# *  referenced above.                                                          *
# ******************************************************************************/

# define
PATH_TO_FOLDER_ROOT=/home/root/styl_bigeye
PATH_TO_FOLDER_APP=$PATH_TO_FOLDER_ROOT/apps
PATH_TO_FOLDER_BIGEYE=$PATH_TO_FOLDER_APP/bigeye
PATH_TO_FOLDER_SVC=$PATH_TO_FOLDER_APP/svc
PATH_TO_FOLDER_DOWNLOADER=$PATH_TO_FOLDER_APP/downloader
PATH_TO_FOLDER_DOWNLOADED=$PATH_TO_FOLDER_ROOT/download/
PATH_TO_FILE_DOWNLOADED=$PATH_TO_FOLDER_DOWNLOADED/app.tar.gz
PATH_TO_FOLDER_FLASHINGAPP=$PATH_TO_FOLDER_APP/flashingapp
PATH_TO_SIGNATURE_FILE=$PATH_TO_FOLDER_FLASHINGAPP/

# variable

## run bigeye
function run_bigeye {
	echo "run BigEye"
   	#run svc
    cd $PATH_TO_FOLDER_BIGEYE
    chmod +x run.sh
    ./run.sh 
}

## run run downloader
function run_downloader {
echo "run downloader"
   	#run svc
    cd $PATH_TO_FOLDER_DOWNLOADER
    chmod +x run.sh

    # run downloader in background
    ./run.sh &
}

## run SVC
function run_svc {
	echo "run SVC"
   	#run svc
    cd $PATH_TO_FOLDER_SVC
    chmod +x run.sh
    
    # run svc in background
    ./run.sh &
}

## check to exit script
function check_exit_script {

	if read -t 10 response; then 
        exit 0
    else
	echo "reboot"
    	reboot
    fi
}

## main process
function do_process {
	if [ -f "${PATH_TO_FILE_DOWNLOADED}" ]; then
    	cd $PATH_TO_FOLDER_FLASHINGAPP
        chmod +x run.sh
        ./run.sh OTA $PATH_TO_FOLDER_DOWNLOADED $PATH_TO_SIGNATURE_FILE
    	reboot
	else
		# run svc
		run_svc

		# run downloader
#		run_downloader

		# run bigeye
		run_bigeye
	fi
}

# run main process
do_process

# check to exit script
check_exit_script

