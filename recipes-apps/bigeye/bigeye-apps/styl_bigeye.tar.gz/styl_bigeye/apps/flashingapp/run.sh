echo "run flashingapp"
echo "./FlashingApplication -m $1 -p $2 -s $3 --platform linuxfb:/dev/fb0:rotation=0"
./FlashingApplication -m $1 -p $2 -s $3 --platform linuxfb:/dev/fb0:rotation=0
