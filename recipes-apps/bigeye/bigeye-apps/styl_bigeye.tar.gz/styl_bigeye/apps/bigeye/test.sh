#!/bin/bash
data=$(cat config.xml | awk 'gsub(/<device_id>|<\/device_id>/,x)')
echo "data: $data"
