echo "Start to update great_white_kiosk apllication"
sourcePath=$1
appName=$2
if [[ $1 == "/dev/sd"* ]]
then
   if [ -e $1 ]
   then
       echo "mount patition $1"
       mount $1 /media
       if [ -e /media/$appName ]
       then
           echo "Updating....." 
           cp /media/$appName .
           sync
           echo "Updated sucessfully"
       else
           echo "Could not see $appName file, pls check USB"
       fi
   else
       echo "$1 is invalid patition"
   fi
else
   echo "please enter correct patition"
fi
