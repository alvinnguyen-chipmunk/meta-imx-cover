HERE=$(pwd)

echo "Run bigeye application"
${HERE}/bigeye --platform linuxfb:/dev/fb0:rotation=0 
