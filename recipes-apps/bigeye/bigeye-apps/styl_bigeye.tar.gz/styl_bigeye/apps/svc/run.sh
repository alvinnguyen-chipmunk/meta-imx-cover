echo "run svc"
chmod +x svc
#./svc --platform linuxfb:/dev/fb0:rotation=0 
./svc
